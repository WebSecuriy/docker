#!/usr/bin/env bash
# kali VM 에서: ./run-receiver.sh
# gen-certs.sh 를 먼저 실행해서 certs/server.pem, certs/server-key.pem 이 있어야 함.
set -euo pipefail
cd "$(dirname "$0")/fixtures"

echo "receiver(공격자 수신 서버) 기동: 0.0.0.0:8443 (Ctrl+C로 종료)"
python3 server.py \
  --host 0.0.0.0 \
  --port 8443 \
  --target "http://internal:8000/reports/alpha" \
  --db ../data/fixture.sqlite3 \
  --cert ../certs/server.pem \
  --key ../certs/server-key.pem
