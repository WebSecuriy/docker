#!/usr/bin/env bash
# kali VM 에서, kali-files 폴더 그 자리에서 실행: ./gen-certs.sh 192.168.40.30
# 기본값 IP도 192.168.40.30 으로 맞춰뒀으니 그냥 인자 없이 ./gen-certs.sh 로 실행해도 됨.
#
# 결과 (certs/ 폴더, fixtures/ 옆):
#   certs/ca.pem                      -> webhook VM 의 certs/ca.pem 자리로 복사
#   certs/server.pem, server-key.pem  -> 이 Kali VM 에 그대로 둠 (run-receiver.sh 가 사용)
set -euo pipefail
RECEIVER_IP="${1:-192.168.40.30}"

cd "$(dirname "$0")/certs"

openssl genrsa -out ca-key.pem 2048
openssl req -x509 -new -nodes -key ca-key.pem -sha256 -days 3650 \
  -subj "/CN=websec-lab-ca" -out ca.pem

openssl genrsa -out server-key.pem 2048
openssl req -new -key server-key.pem -subj "/CN=receiver" -out server.csr

cat > server.ext <<EOF
subjectAltName = DNS:receiver, DNS:kali, IP:${RECEIVER_IP}
EOF

openssl x509 -req -in server.csr -CA ca.pem -CAkey ca-key.pem -CAcreateserial \
  -out server.pem -days 825 -sha256 -extfile server.ext

rm -f server.csr ca.srl

echo
echo "생성 완료. 이 폴더(certs/) 안:"
ls -1
echo
echo "다음 할 일: 이 중 ca.pem 파일 하나만 webhook VM 의 webhook-files/certs/ 안에 복사(덮어쓰기)할 것."
echo "server.pem / server-key.pem 은 이 Kali VM 에 그대로 둔다 (옮길 필요 없음)."
