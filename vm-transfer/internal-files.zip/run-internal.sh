#!/usr/bin/env bash
# internal VM 에서: ./run-internal.sh
set -euo pipefail
cd "$(dirname "$0")/internal"

export BIND_HOST=0.0.0.0
export PORT=8000
export INTERNAL_DB_PATH=../data/internal.sqlite3

echo "internal(레거시 보고서 API) 서버 기동: 0.0.0.0:8000 (Ctrl+C로 종료)"
python3 server.py
