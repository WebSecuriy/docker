#!/usr/bin/env bash
# webhook VM 에서 실행 (root/sudo 필요).
# Docker 의 compose.block.yaml( webhook 을 protected 네트워크에서 분리 )과
# 동일한 효과를 iptables 로 재현: internal(사내 API) 로의 아웃바운드만 차단하고
# receiver(Kali) 는 그대로 통신 가능하게 둔다.
#
# 사용법:
#   sudo ./layer2-toggle.sh block     # 2계층 방어 ON  (internal 도달 불가)
#   sudo ./layer2-toggle.sh unblock   # 2계층 방어 OFF (baseline 으로 복귀)
#   sudo ./layer2-toggle.sh status
set -euo pipefail
INTERNAL_IP="${INTERNAL_IP:-192.168.40.20}"
COMMENT="ssrf-lab-layer2-block"

case "${1:-}" in
  block)
    if ! iptables -C OUTPUT -d "$INTERNAL_IP" -j DROP -m comment --comment "$COMMENT" 2>/dev/null; then
      iptables -I OUTPUT -d "$INTERNAL_IP" -j DROP -m comment --comment "$COMMENT"
    fi
    echo "[2계층 ON] webhook -> internal($INTERNAL_IP) 차단됨. receiver(Kali)는 그대로 통신 가능."
    ;;
  unblock)
    iptables -D OUTPUT -d "$INTERNAL_IP" -j DROP -m comment --comment "$COMMENT" 2>/dev/null || true
    echo "[2계층 OFF] baseline 으로 복귀."
    ;;
  status)
    iptables -L OUTPUT -n --line-numbers | grep -i "$COMMENT" || echo "현재 차단 규칙 없음 (baseline)"
    ;;
  *)
    echo "usage: $0 {block|unblock|status}" >&2
    exit 1
    ;;
esac
