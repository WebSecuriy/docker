#!/usr/bin/env bash
# webhook VM 에서: ./run-webhook.sh
#
# === 시연(방법 A: 레이어별 독립 검증 + 최종 종합)용 설정 가이드 ===
# 아래 값들을 바꾸고 이 스크립트를 재시작(Ctrl+C 후 재실행)하면 각 계층을 단독으로 테스트할 수 있다.
#   1계층(URL/리다이렉트 검사) 단독 검증 : POLICY=strict, 나머지는 기본값
#   2계층(네트워크 분리) 단독 검증      : POLICY=baseline + layer2-toggle.sh block (webhook VM에서)
#   3계층(접근 제어) 단독 검증          : POLICY=baseline, 칼리에서 attack-*.sh에 다른 토큰 사용
#   4계층(데이터 마스킹) 단독 검증      : POLICY=baseline, RETURN_BODY/STORE_BODY/READ_BODY=mask
#   최종 종합(전체 보호 상태)           : POLICY=strict, RETURN_BODY/STORE_BODY/READ_BODY=mask (아래 기본값 그대로)
# 자세한 명령어는 DEMO-GUIDE.md 참고.
set -euo pipefail
cd "$(dirname "$0")/webhook"

export BIND_HOST=0.0.0.0
export PORT=8000
export DB_PATH=../data/webhook.sqlite3
export BOOTSTRAP_FILE=../config/accounts.json
export URL_EXCEPTIONS_FILE=../config/url-exceptions.lab.local.json

# baseline = 등록시만 검사 / reject = redirect 전면거부 / strict = 매 hop 재검증+다운그레이드 차단
export POLICY=strict
export ENABLED_MODES=mlflow,plane
export RETURN_BODY=mask
export STORE_BODY=mask
export READ_BODY=mask
export BODY_LIMIT=1024
export MAX_RESPONSE_BYTES=65536
export DELIVERY_TIMEOUT=3
export MAX_REDIRECTS=5
export ALLOW_HTTP=true
export CA_FILE=../certs/ca.pem
export INTERNAL_HEALTH_URL=http://internal:8000/health
export CVE_DEMO_MODE=none
export CVE_DEMO_ACK=
export MLFLOW_VERSION_PROFILE=v3.13.0-vulnerable
export MLFLOW_CVE_AUTH_REQUIRED=false
export PLANE_VERSION_PROFILE=v1.3.1-vulnerable
export CVE_DEMO_PLANE_ORIGIN=
export PLANE_LOG_FILTER=none

echo "webhook 서버 기동: 0.0.0.0:8000 (Ctrl+C로 종료)"
python3 server.py
